#LARAVEL
#Module
#Python 2.7
- Get Database + SMTP
- PHPUNIT
- Laravel Token Unrealize RCE
----------------------------------
- cd laravel
- pip install requests
- pip install termcolor
- python run.py

- Youtube : https://www.youtube.com/channel/UCwDVCs0PvycfXWNjEnK2d-w
