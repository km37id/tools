#LARAVEL
#Module
#Python 2.7
- Get Database + SMTP
- PHPUNIT
- Laravel Token Unrealize RCE

- git clone https://github.com/rintod/laravel
- cd laravel
- pip install termcolor
- python run.py